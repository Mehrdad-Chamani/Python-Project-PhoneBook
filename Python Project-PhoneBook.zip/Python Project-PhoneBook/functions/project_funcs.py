
def show_menu():
    print('************************')
    print('1 - Add')
    print('2 - Show All')
    print('3 - Search')
    print('4 - Update')
    print('5 - Delete')
    print('0 - Exit')
    print('************************')

def fake_data(contacts):
    contacts['ali'] = '09121111111'
    contacts['reza'] = '09122222222'
    contacts['hamid'] = '09123333333'

def add_new_contact(contacts):
    name = input('Contact Name ? : ')   
    mobile = input('Contact Mobile ? : ')   

    contacts[name] = mobile

def show_all_contacts(contacts):
    for contact in contacts:   
        print(contact + '\t' + contacts.get(contact))
        

def search_contact(contacts, name):
    flag = False   
    for contact in contacts:
        if contact == name:
            print(contact + '\t' + contacts.get(contact))
            flag = True
            break
    
    return flag   # ---> ( خروجي ضروري ) جواب بده ، پيدا کردي يا نکردي ؟ 

def update_contact(contacts, name):
    mobile = input('New Mobile ? : ')
    flag = False
    for contact in contacts:
        if contact == name:
            contacts[name] = mobile
            flag = True
            break
    
    return flag   # ---> جواب بده ، آپديت کردي يا نکردي ؟ ( خروجي اختياري )  

def delete_contact(contacts, name):
    flag = False
    for contact in contacts:
        if contact == name:
            del contacts[name]
            flag = True
            break
    
    return flag   # ---> جواب بده ، حذف کردي يا نکردي ؟ ( خروجي اختياري )