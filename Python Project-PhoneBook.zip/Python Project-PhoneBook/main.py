
from functions.project_funcs import *

contacts = {}

fake_data(contacts)

show_menu()
def phonebook():
    try:
        while True:
            item = int(input('Choose an item : . . . '))
            if item == 1:
                add_new_contact(contacts)
            elif item == 2:
                show_all_contacts(contacts)
            elif item == 3:
                name = input('Who are you looking for ? : ')   
                result = search_contact(contacts, name)
                if not result:
                    print('Cannot find the contact with name : ', name)
            elif item == 4:
                name = input('Who are you looking for ? : ')   
                search_result = search_contact(contacts, name)
                if search_result:
                    update_result = update_contact(contacts, name)
                    if update_result:
                        print("Contact \'%s\' updated successfully" %(name))
                else:
                    print('Cannot find the contact with name : ', name)
            elif item == 5:
                name = input('Who are you looking for ? : ')   
                search_result = search_contact(contacts, name)
                if search_result:
                    delete_result = delete_contact(contacts, name)
                    if delete_result:
                        print("Contact \'%s\' deleted successfully" % (name))
                else:
                    print('Cannot find the contact with name : ', name)
            elif item == 0:
                response = input('Are you sure ? (y / n) : ')
                if response.lower() == 'y':
                    exit()
            else:
                print('Invalid Item !')
                show_menu()

    except ValueError:
        print("The input value for the 'item' is not defined!, \nPlease choose an integer from 0 to 5")
        show_menu()
        phonebook()


phonebook()